# Exercice dirigé: Mise en forme du texte

Faire un exemple de chaque valeur en utilsant une classe spécifique à chaque fois.

## Hauteur de ligne
Pour les articles: 2

## Code
Couleur: #111
Police: sans-serif

## Petits paragraphes (.small) utilisés pour la propriété white-space
Largeur: 200px
Couleur de fond: #ccc